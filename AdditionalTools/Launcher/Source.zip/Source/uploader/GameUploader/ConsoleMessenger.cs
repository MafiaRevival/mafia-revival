﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace GameUploader
{
    class ConsoleMessenger
    {
        List<ConsoleMessage> AllMessages = new List<ConsoleMessage>();

        public ConsoleMessenger()
        {
            //UpdateThread = new Thread(new ThreadStart(UpdateText));
            //UpdateThread.Start();
        }

        ~ConsoleMessenger()
        {
            //UpdateThread.Abort();
        }

        class ConsoleMessage
        {
            public string Text;
            public ConsoleColor Color;
            public ConsoleMessage(string text, ConsoleColor color)
            {
                Text = text;
                Color = color;
            }
        }

        public int AddMessage(string text, ConsoleColor color = ConsoleColor.Gray)
        {
            int line = AllMessages.Count;
            Console.ForegroundColor = color;
            Console.WriteLine(text);
            AllMessages.Add(new ConsoleMessage(text, color));
            return line;
        }

        public void EditMessage(int messageId, string newText)
        {
            if (AllMessages[messageId].Text != newText)
            {
                int x = Console.CursorLeft;
                int y = Console.CursorTop;

                AllMessages[messageId].Text = newText;

                // writes a line of empty spaces
                Console.SetCursorPosition(0, messageId);
                Console.Write(new string(' ', Console.WindowWidth));

                // writes the new message
                Console.SetCursorPosition(0, messageId);
                Console.Write(newText);

                Console.SetCursorPosition(x, y);
            }
        }
    }
}
