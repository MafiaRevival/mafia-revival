﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Launcher01
{
    class AdvancedButton : Button
    {
        public Image ActiveImage { get; set; }
        public Image HoveredImage { get; set; }
        public Image PressedImage { get; set; }
        public Image InactiveImage { get; set; }

        [System.ComponentModel.DefaultValue(System.Windows.Forms.FlatStyle.Flat)]
        public new FlatStyle FlatStyle
        {
            get { return base.FlatStyle; }
            set { base.FlatStyle = value; }
        }

        public AdvancedButton()
        {
            FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            FlatAppearance.MouseDownBackColor = Color.Transparent;
            FlatAppearance.MouseOverBackColor = Color.Transparent;
            BackgroundImage = ActiveImage;
            Form1.buttonsToInitialize.Add(this);
        }

        protected override void OnMouseEnter(System.EventArgs e)
        {
            base.OnMouseEnter(e);
            if (HoveredImage == null) return;

            if (Enabled)
            {
                BackgroundImage = HoveredImage;
            }
        }

        protected override void OnMouseLeave(System.EventArgs e)
        {
            base.OnMouseLeave(e);
            if (HoveredImage == null) return;

            if (Enabled)
            {
                BackgroundImage = ActiveImage;
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (PressedImage == null) return;

            if (Enabled)
            {
                BackgroundImage = PressedImage;
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);

            if (Enabled)
            {
                BackgroundImage = HoveredImage;
            }
        }

        public new bool Enabled
        {
            get
            {
                return base.Enabled;
            }
            set
            {
                base.Enabled = value;
                if (value)
                {
                    BackgroundImage = ActiveImage;
                }
                else
                {
                    BackgroundImage = InactiveImage;
                }
            }
        }


    }
}
