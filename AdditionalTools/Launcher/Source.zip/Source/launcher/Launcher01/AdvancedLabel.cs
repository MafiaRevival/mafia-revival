﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Launcher01
{
    class AdvancedLabel : Label
    {
        public AdvancedLabel()
        {
            Form1.labelsToInitialize.Add(this);
        }
    }
}
